# MediTrack Web App

This is used so users can login and know when they need to take their medication.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

### PHP Config File

Replace the lines below in the [config] file with your database info.

```php
$dbname = ''; // database name
$dbuser = ''; // username
$dbpass = ''; // password
```

### SQL Statements

Import the sql file in the 'sql.zip' 
## Screenshots


## Owners

- **Dennis Onyango** 
- **Jane Mwangi** 
## Special Thanks

(https://github.com/ArrobeFr) - the source code for the calendar.

## License

